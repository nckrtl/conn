import type { ImageSourceInternal } from './EnrichedMarkdownNativeComponent';
import type { EnrichedMarkdownTextProps } from './types/MarkdownTextProps';
import type { MarkdownMediaAsset } from './types/media';
export type NativeImageAsset = MarkdownMediaAsset & {
    anchor: string;
};
type Resolver = NonNullable<EnrichedMarkdownTextProps['resolveImageSource']>;
/** Per-occurrence decisions; superseded promises still count against the bound. */
export declare class ImageSourceState {
    private resolver?;
    private lineage;
    private entries;
    private active;
    private running;
    private changed?;
    configure(resolver: Resolver | undefined, lineage: number, assets: NativeImageAsset[]): void;
    sources(): ImageSourceInternal[];
    start(changed: () => void): void;
    stop(): void;
    private pump;
}
export {};
//# sourceMappingURL=imageSourceState.d.ts.map