import type { MediaFrameInternal } from './EnrichedMarkdownNativeComponent';
export interface MediaMeasurement {
    id: string;
    width: number;
    height: number;
}
export declare const sameMediaSize: (a: number, b: number) => boolean;
/** Accept only finite native frames with usable widths. */
export declare const validMediaFrames: (frames: readonly MediaFrameInternal[]) => MediaFrameInternal[];
/** A width change requires React to measure again before native uses the height. */
export declare const mediaOverrideForFrame: (id: string, frame: MediaFrameInternal | undefined, measurement: MediaMeasurement | undefined) => MediaMeasurement;
/** Reject stale onLayout callbacks and suppress subpixel feedback loops. */
export declare const acceptMediaMeasurement: (eventRevision: number, revision: number, frame: MediaFrameInternal | undefined, next: MediaMeasurement, previous: MediaMeasurement | undefined) => boolean;
//# sourceMappingURL=mediaSlotState.d.ts.map