import type { NativeImageAsset } from '../imageSourceState';
import type { EnrichedMarkdownTextProps } from '../types/MarkdownTextProps';
export declare function useImageSources(resolver: EnrichedMarkdownTextProps['resolveImageSource'], continuityStart: number, assetsRevision: number, assets: NativeImageAsset[]): {
    enableImageSourceResolution: boolean;
    imageSourcesContinuityStart: number;
    imageSourcesRevision: number;
    imageSources: import("../EnrichedMarkdownNativeComponent").ImageSourceInternal[];
};
//# sourceMappingURL=useImageSources.d.ts.map