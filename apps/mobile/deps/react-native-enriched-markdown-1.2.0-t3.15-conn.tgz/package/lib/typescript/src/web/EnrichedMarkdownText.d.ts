import type { EnrichedMarkdownTextProps } from '../types/MarkdownTextProps.web';
export declare const EnrichedMarkdownText: ({ markdown, markdownStyle, md4cFlags, linkRecognition, onLinkPress, onLinkLongPress, onImagePress, onTaskListItemPress, onCodeBlockPress, enableTaskListItemToggle, allowTrailingMargin, containerStyle, selectable, dir, selectionColor, testID, ...rest }: EnrichedMarkdownTextProps) => import("react/jsx-runtime").JSX.Element | null;
export default EnrichedMarkdownText;
//# sourceMappingURL=EnrichedMarkdownText.d.ts.map