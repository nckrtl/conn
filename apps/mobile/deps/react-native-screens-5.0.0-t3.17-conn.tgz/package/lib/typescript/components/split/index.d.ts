import SplitHost from './SplitHost';
export type { DisplayModeWillChangeEvent, // TODO: This event should be renamed to match the convention
SplitDisplayModeButtonVisibility, SplitBehavior, SplitPrimaryEdge, SplitPrimaryBackgroundStyle, SplitDisplayMode, SplitHostOrientation, SplitColumnMetrics, SplitNavigableColumn, SplitHostCommands, SplitHostProps, } from './SplitHost.types';
export type { SplitScreenColumnType, SplitScreenActivityMode, SplitScreenDismissEvent, SplitScreenProps, SplitStackProps, } from './SplitScreen.types';
export type { SplitHeaderConfigProps, SplitHeaderConfigRef, } from './SplitHeaderConfig.types';
export declare const Split: {
    Host: typeof SplitHost;
    Column: (props: import("./SplitScreen.types").SplitScreenProps) => import("react").JSX.Element;
    Stack: (props: import("./SplitScreen.types").SplitStackProps) => import("react").JSX.Element;
    Screen: (props: import("./SplitScreen.types").SplitScreenProps) => import("react").JSX.Element;
    Inspector: (props: import("./SplitScreen.types").SplitScreenProps) => import("react").JSX.Element;
    HeaderConfig: import("react").ForwardRefExoticComponent<import("../stack").StackHeaderConfigProps & import("react").RefAttributes<import("../stack").StackHeaderConfigRef>>;
};
//# sourceMappingURL=index.d.ts.map