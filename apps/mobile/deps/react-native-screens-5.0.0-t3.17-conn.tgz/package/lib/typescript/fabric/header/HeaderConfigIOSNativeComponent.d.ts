import type { CodegenTypes as CT, HostComponent, ProcessedColorValue, ColorValue, ViewProps } from 'react-native';
import type { PlatformIconIOS, StackHeaderMenuIOS } from './HeaderItemIOSNativeComponent';
import { UnsafeMixed } from '../codegenUtils';
type BackButtonDisplayMode = 'default' | 'generic' | 'minimal';
type NavigationItemStyle = 'navigator' | 'browser' | 'editor';
export type HeaderAppearance = {
    backgroundColor?: ProcessedColorValue | null | undefined;
    shadowColor?: ProcessedColorValue | null | undefined;
    titleFontFamily?: string | undefined;
    titleFontSize?: CT.Float | undefined;
    titleFontWeight?: string | undefined;
    titleFontStyle?: string | undefined;
    titleFontColor?: ProcessedColorValue | null | undefined;
    largeTitleFontFamily?: string | undefined;
    largeTitleFontSize?: CT.Float | undefined;
    largeTitleFontWeight?: string | undefined;
    largeTitleFontStyle?: string | undefined;
    largeTitleFontColor?: ProcessedColorValue | null | undefined;
    subtitleFontFamily?: string | undefined;
    subtitleFontSize?: CT.Float | undefined;
    subtitleFontWeight?: string | undefined;
    subtitleFontStyle?: string | undefined;
    subtitleFontColor?: ProcessedColorValue | null | undefined;
};
export type MenuItemPressEvent = Readonly<{
    menuItemId: string;
}>;
export type MenuSelectionChangeEvent = Readonly<{
    menuId: string;
    selectedMenuItemIds: string[];
}>;
export interface NativeProps extends ViewProps {
    title?: string | undefined;
    subtitle?: string | undefined;
    hidden?: CT.WithDefault<boolean, false>;
    transparent?: CT.WithDefault<boolean, false>;
    backButtonHidden?: CT.WithDefault<boolean, false>;
    tintColor?: ColorValue | undefined;
    navigationItemStyle?: CT.WithDefault<NavigationItemStyle, 'navigator'>;
    backButtonTitle?: string | undefined;
    backButtonDisplayMode?: CT.WithDefault<BackButtonDisplayMode, 'default'>;
    backButtonMenuEnabled?: CT.WithDefault<boolean, true>;
    largeTitle?: string | undefined;
    largeSubtitle?: string | undefined;
    largeTitleEnabled?: CT.WithDefault<boolean, false>;
    prompt?: string | undefined;
    titleMenu?: UnsafeMixed<StackHeaderMenuIOS> | undefined;
    standardAppearance?: UnsafeMixed<HeaderAppearance> | undefined;
    scrollEdgeAppearance?: UnsafeMixed<HeaderAppearance> | undefined;
    onMenuItemPress?: CT.DirectEventHandler<MenuItemPressEvent> | undefined;
    onMenuSelectionChange?: CT.DirectEventHandler<MenuSelectionChangeEvent> | undefined;
}
type ComponentType = HostComponent<NativeProps>;
export interface NativeMenuElementOptionsIOS {
    title?: string | null | undefined;
    icon?: UnsafeMixed<PlatformIconIOS> | null | undefined;
    toggleState?: boolean | undefined;
}
export interface NativeCommands {
    setMenuItemOptions: (viewRef: React.ComponentRef<ComponentType>, menuElementId: string, options: NativeMenuElementOptionsIOS[]) => void;
    setMenuOptions: (viewRef: React.ComponentRef<ComponentType>, menuElementId: string, options: NativeMenuElementOptionsIOS[]) => void;
}
export declare const Commands: NativeCommands;
declare const _default: HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=HeaderConfigIOSNativeComponent.d.ts.map